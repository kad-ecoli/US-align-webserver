#!/usr/bin/env pymol
cmd.load("TMalign.sup.pdb", "structure1")
cmd.load("native_7bg9B.pdb", "structure2")
hide all
set all_states, off
show cartoon, structure1 and ( i.    1 or i.    2 or i.    4 or i.    5 or i.    6 or i.    7 or i.    8 or i.    9 or i.   13 or i.   14 or i.   15 or i.   16 or i.   17 or i.   18 or i.   19 or i.   20 or i.   21 or i.   22 or i.   23 or i.   24 or i.   25 or i.   26 or i.   27 or i.   28 or i.   29 or i.   30 or i.   31 or i.   32 or i.   33 or i.   34 or i.   35 or i.   36 or i.   37 or i.   38 or i.   39 or i.   40 or i.   42 or i.   43 or i.   44 or i.   45 or i.   46 or i.   47 or i.   48 or i.   50 or i.   51 or i.   52 or i.   54 or i.   55 or i.   56 or i.   57 or i.   58 or i.   59 or i.   60 or i.   61 or i.   62 or i.   63 or i.   64 or i.   65 or i.   66 or i.   67 or i.   68 or i.   69 or i.   70 or i.   71 or i.   72 or i.   73 or i.   74 or i.   75 or i.   76 or i.   77 or i.   78 or i.   79 or i.   80 or i.   81 or i.   82 or i.   83 or i.   84 or i.   85 or i.   87 or i.   88)
show cartoon, structure2 and ( i.  239 or i.  240 or i.  241 or i.  242 or i.  243 or i.  244 or i.  245 or i.  246 or i.  251 or i.  252 or i.  253 or i.  254 or i.  255 or i.  256 or i.  257 or i.  258 or i.  259 or i.  260 or i.  261 or i.  262 or i.  263 or i.  264 or i.  265 or i.  266 or i.  267 or i.  268 or i.  269 or i.  270 or i.  271 or i.  272 or i.  273 or i.  274 or i.  275 or i.  276 or i.  277 or i.  278 or i.  279 or i.  280 or i.  281 or i.  282 or i.  283 or i.  284 or i.  285 or i.  289 or i.  290 or i.  291 or i.  292 or i.  293 or i.  294 or i.  295 or i.  296 or i.  297 or i.  298 or i.  299 or i.  300 or i.  301 or i.  302 or i.  303 or i.  304 or i.  305 or i.  306 or i.  307 or i.  308 or i.  309 or i.  310 or i.  311 or i.  312 or i.  313 or i.  314 or i.  315 or i.  316 or i.  317 or i.  319 or i.  320 or i.  321 or i.  322 or i.  323 or i.  324 or i.  325 or i.  326)
color blue, structure1
color red, structure2
set ribbon_width, 6
set stick_radius, 0.3
set sphere_scale, 0.25
set ray_shadow, 0
bg_color white
set transparency=0.2
zoom polymer and ((structure1) or (structure2))

