#!/usr/bin/env pymol
cmd.load("TMalign.sup.pdb", "structure1")
cmd.load("native_7bg9B.pdb", "structure2")
hide all
set all_states, off
remove not n. CA and not n. C3'
bond structure1 and i.    1, i.    2
bond structure1 and i.    2, i.    4
bond structure1 and i.    4, i.    5
bond structure1 and i.    5, i.    6
bond structure1 and i.    6, i.    7
bond structure1 and i.    7, i.    8
bond structure1 and i.    8, i.    9
bond structure1 and i.    9, i.   13
bond structure1 and i.   13, i.   14
bond structure1 and i.   14, i.   15
bond structure1 and i.   15, i.   16
bond structure1 and i.   16, i.   17
bond structure1 and i.   17, i.   18
bond structure1 and i.   18, i.   19
bond structure1 and i.   19, i.   20
bond structure1 and i.   20, i.   21
bond structure1 and i.   21, i.   22
bond structure1 and i.   22, i.   23
bond structure1 and i.   23, i.   24
bond structure1 and i.   24, i.   25
bond structure1 and i.   25, i.   26
bond structure1 and i.   26, i.   27
bond structure1 and i.   27, i.   28
bond structure1 and i.   28, i.   29
bond structure1 and i.   29, i.   30
bond structure1 and i.   30, i.   31
bond structure1 and i.   31, i.   32
bond structure1 and i.   32, i.   33
bond structure1 and i.   33, i.   34
bond structure1 and i.   34, i.   35
bond structure1 and i.   35, i.   36
bond structure1 and i.   36, i.   37
bond structure1 and i.   37, i.   38
bond structure1 and i.   38, i.   39
bond structure1 and i.   39, i.   40
bond structure1 and i.   40, i.   42
bond structure1 and i.   42, i.   43
bond structure1 and i.   43, i.   44
bond structure1 and i.   44, i.   45
bond structure1 and i.   45, i.   46
bond structure1 and i.   46, i.   47
bond structure1 and i.   47, i.   48
bond structure1 and i.   48, i.   50
bond structure1 and i.   50, i.   51
bond structure1 and i.   51, i.   52
bond structure1 and i.   52, i.   54
bond structure1 and i.   54, i.   55
bond structure1 and i.   55, i.   56
bond structure1 and i.   56, i.   57
bond structure1 and i.   57, i.   58
bond structure1 and i.   58, i.   59
bond structure1 and i.   59, i.   60
bond structure1 and i.   60, i.   61
bond structure1 and i.   61, i.   62
bond structure1 and i.   62, i.   63
bond structure1 and i.   63, i.   64
bond structure1 and i.   64, i.   65
bond structure1 and i.   65, i.   66
bond structure1 and i.   66, i.   67
bond structure1 and i.   67, i.   68
bond structure1 and i.   68, i.   69
bond structure1 and i.   69, i.   70
bond structure1 and i.   70, i.   71
bond structure1 and i.   71, i.   72
bond structure1 and i.   72, i.   73
bond structure1 and i.   73, i.   74
bond structure1 and i.   74, i.   75
bond structure1 and i.   75, i.   76
bond structure1 and i.   76, i.   77
bond structure1 and i.   77, i.   78
bond structure1 and i.   78, i.   79
bond structure1 and i.   79, i.   80
bond structure1 and i.   80, i.   81
bond structure1 and i.   81, i.   82
bond structure1 and i.   82, i.   83
bond structure1 and i.   83, i.   84
bond structure1 and i.   84, i.   85
bond structure1 and i.   85, i.   87
bond structure1 and i.   87, i.   88
bond structure2 and i.  239, i.  240
bond structure2 and i.  240, i.  241
bond structure2 and i.  241, i.  242
bond structure2 and i.  242, i.  243
bond structure2 and i.  243, i.  244
bond structure2 and i.  244, i.  245
bond structure2 and i.  245, i.  246
bond structure2 and i.  246, i.  251
bond structure2 and i.  251, i.  252
bond structure2 and i.  252, i.  253
bond structure2 and i.  253, i.  254
bond structure2 and i.  254, i.  255
bond structure2 and i.  255, i.  256
bond structure2 and i.  256, i.  257
bond structure2 and i.  257, i.  258
bond structure2 and i.  258, i.  259
bond structure2 and i.  259, i.  260
bond structure2 and i.  260, i.  261
bond structure2 and i.  261, i.  262
bond structure2 and i.  262, i.  263
bond structure2 and i.  263, i.  264
bond structure2 and i.  264, i.  265
bond structure2 and i.  265, i.  266
bond structure2 and i.  266, i.  267
bond structure2 and i.  267, i.  268
bond structure2 and i.  268, i.  269
bond structure2 and i.  269, i.  270
bond structure2 and i.  270, i.  271
bond structure2 and i.  271, i.  272
bond structure2 and i.  272, i.  273
bond structure2 and i.  273, i.  274
bond structure2 and i.  274, i.  275
bond structure2 and i.  275, i.  276
bond structure2 and i.  276, i.  277
bond structure2 and i.  277, i.  278
bond structure2 and i.  278, i.  279
bond structure2 and i.  279, i.  280
bond structure2 and i.  280, i.  281
bond structure2 and i.  281, i.  282
bond structure2 and i.  282, i.  283
bond structure2 and i.  283, i.  284
bond structure2 and i.  284, i.  285
bond structure2 and i.  285, i.  289
bond structure2 and i.  289, i.  290
bond structure2 and i.  290, i.  291
bond structure2 and i.  291, i.  292
bond structure2 and i.  292, i.  293
bond structure2 and i.  293, i.  294
bond structure2 and i.  294, i.  295
bond structure2 and i.  295, i.  296
bond structure2 and i.  296, i.  297
bond structure2 and i.  297, i.  298
bond structure2 and i.  298, i.  299
bond structure2 and i.  299, i.  300
bond structure2 and i.  300, i.  301
bond structure2 and i.  301, i.  302
bond structure2 and i.  302, i.  303
bond structure2 and i.  303, i.  304
bond structure2 and i.  304, i.  305
bond structure2 and i.  305, i.  306
bond structure2 and i.  306, i.  307
bond structure2 and i.  307, i.  308
bond structure2 and i.  308, i.  309
bond structure2 and i.  309, i.  310
bond structure2 and i.  310, i.  311
bond structure2 and i.  311, i.  312
bond structure2 and i.  312, i.  313
bond structure2 and i.  313, i.  314
bond structure2 and i.  314, i.  315
bond structure2 and i.  315, i.  316
bond structure2 and i.  316, i.  317
bond structure2 and i.  317, i.  319
bond structure2 and i.  319, i.  320
bond structure2 and i.  320, i.  321
bond structure2 and i.  321, i.  322
bond structure2 and i.  322, i.  323
bond structure2 and i.  323, i.  324
bond structure2 and i.  324, i.  325
bond structure2 and i.  325, i.  326
show stick, structure1 and ( i.    1 or i.    2 or i.    4 or i.    5 or i.    6 or i.    7 or i.    8 or i.    9 or i.   13 or i.   14 or i.   15 or i.   16 or i.   17 or i.   18 or i.   19 or i.   20 or i.   21 or i.   22 or i.   23 or i.   24 or i.   25 or i.   26 or i.   27 or i.   28 or i.   29 or i.   30 or i.   31 or i.   32 or i.   33 or i.   34 or i.   35 or i.   36 or i.   37 or i.   38 or i.   39 or i.   40 or i.   42 or i.   43 or i.   44 or i.   45 or i.   46 or i.   47 or i.   48 or i.   50 or i.   51 or i.   52 or i.   54 or i.   55 or i.   56 or i.   57 or i.   58 or i.   59 or i.   60 or i.   61 or i.   62 or i.   63 or i.   64 or i.   65 or i.   66 or i.   67 or i.   68 or i.   69 or i.   70 or i.   71 or i.   72 or i.   73 or i.   74 or i.   75 or i.   76 or i.   77 or i.   78 or i.   79 or i.   80 or i.   81 or i.   82 or i.   83 or i.   84 or i.   85 or i.   87 or i.   88)
show stick, structure2 and ( i.  239 or i.  240 or i.  241 or i.  242 or i.  243 or i.  244 or i.  245 or i.  246 or i.  251 or i.  252 or i.  253 or i.  254 or i.  255 or i.  256 or i.  257 or i.  258 or i.  259 or i.  260 or i.  261 or i.  262 or i.  263 or i.  264 or i.  265 or i.  266 or i.  267 or i.  268 or i.  269 or i.  270 or i.  271 or i.  272 or i.  273 or i.  274 or i.  275 or i.  276 or i.  277 or i.  278 or i.  279 or i.  280 or i.  281 or i.  282 or i.  283 or i.  284 or i.  285 or i.  289 or i.  290 or i.  291 or i.  292 or i.  293 or i.  294 or i.  295 or i.  296 or i.  297 or i.  298 or i.  299 or i.  300 or i.  301 or i.  302 or i.  303 or i.  304 or i.  305 or i.  306 or i.  307 or i.  308 or i.  309 or i.  310 or i.  311 or i.  312 or i.  313 or i.  314 or i.  315 or i.  316 or i.  317 or i.  319 or i.  320 or i.  321 or i.  322 or i.  323 or i.  324 or i.  325 or i.  326)
color blue, structure1
color red, structure2
set ribbon_width, 6
set stick_radius, 0.3
set sphere_scale, 0.25
set ray_shadow, 0
bg_color white
set transparency=0.2
zoom polymer and ((structure1) or (structure2))

